
# Student Dashboard

This is a simple static student dashboard built with HTML, CSS, and JavaScript.

## Features
- Daily Attendance
- Profile Details
- Timetable
- Grades
- Assignments
- Events
- Leave Request
- Materials
- Notifications
- Feedback

## Deployment
To deploy this on Render:
1. Upload to GitHub.
2. Connect your GitHub repo to Render.
3. Deploy as a static site.

Enjoy!
